function valida() {
	let nombre=document.getElementById("nombre").value;
    let correo=document.getElementById("correo").value;
    let contraseña=document.getElementById("contraseña").value;

    if(nombre===""|| correo===""||contraseña===""){
        alert("Complete todos los campos del formulario");
        return false;
    }
    else if(nombre.length<1||nombre.length>35){
        alert("Ingrese nombre completo");
        return false;
    }
    else if(correo.length!=10){
        alert("El correo electrónico es inválido");
        return false;
    }
    else if(contraseña.length<8||contraseña.lenth>12){
        alert("La clave que ingreso es invalida, deben ser 10 caracteres");
        return false;
    }
    
    console.log(nombre);
    console.log(correo);
    console.log(contraseña);
}